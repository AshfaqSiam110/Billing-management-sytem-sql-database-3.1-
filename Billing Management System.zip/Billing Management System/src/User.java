/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
class User {
    private int newBuyerId;
    private String name,number,email,addres,gender;
    
    public User(int newBuyerId,String name,String number,String email,String addres,String gender){
       
        this.newBuyerId=newBuyerId;
        this.name=name;
        this.number=number;
        this.email=email;
        this.addres=addres;
        this.gender=gender;
        
    }
    
    public int getnewBuyerId(){
       return newBuyerId;
    }
    public String getname(){
       return name;
    }
    public String getnumber(){
       return number;
    }
    public String getemail(){
       return email;
    }
    public String getaddres(){
       return addres;
    }
    public String getgender(){
       return gender;
    }
    
}
