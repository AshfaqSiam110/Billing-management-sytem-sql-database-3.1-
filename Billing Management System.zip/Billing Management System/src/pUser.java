/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
class pUser {
    private int newProductId;
    private String pname,prate,pdescription,activate;
    
    public pUser(int newProductId,String pname,String prate,String pdescription,String activate){
       
        this.newProductId=newProductId;
        this.pname=pname;
        this.prate=prate;
        this.pdescription=pdescription;
        this.activate=activate;
        
        
    }
    
    public int getnewProductId(){
       return newProductId;
    }
    public String getpname(){
       return pname;
    }
    public String getprate(){
       return prate;
    }
    public String getpdescription(){
       return pdescription;
    }
    public String getactivate(){
       return activate;
    }
    
    
}
